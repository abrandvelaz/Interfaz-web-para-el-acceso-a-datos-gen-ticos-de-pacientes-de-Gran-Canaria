package org.uichuimi.database.controllers.variants.utils;

import java.util.List;

public class PostVariants {
	Long start;
	Long end;
	Double gmaf;
	Double polyphen;
	Double sift;
	List<Long> chromosomes;
	List<Long> genes;
	List<Long> effects;
	List<Long> impacts;
	List<Long> biotypes;
	List<GenotypeFilter> genotypeFilters;
	List<String> identifiers;
    Integer page;
	Integer size;

	public Long getStart() { return start; }

	public Long getEnd() {
		return end;
	}

	public Double getGmaf() { return gmaf; }

	public List<Long> getEffects() { return effects; }

	public List<Long> getImpacts() { return impacts; }

	public List<Long> getChromosomes() {
		return chromosomes;
	}

	public List<Long> getGenes() {
		return genes;
	}

	public List<Long> getBiotypes() { return biotypes; }

	public List<String> getIdentifiers(){ return identifiers; }

	public List<GenotypeFilter> getGenotypeFilters() { return genotypeFilters; }

	public Double getPolyphen() { return polyphen; }

	public Double getSift() { return sift; }

	public Integer getPage() {
		if (page == null) {
			return 0;
		}
		return page;
	}

	public Integer getSize() {
		if (size == null) {
			return 20;
		}
		return size;
	}
}


