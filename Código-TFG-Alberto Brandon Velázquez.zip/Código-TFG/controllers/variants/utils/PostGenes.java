package org.uichuimi.database.controllers.variants.utils;

import java.util.List;

public class PostGenes {
	List<Long> ids;

	public List<Long> getIds() {
		return ids;
	}
}

