package org.uichuimi.database.controllers.variants.utils;

import java.util.List;

public class GenotypeFilter {
	List<Long> individual;
	List<Long> genotypeType;
	String selector;
	Integer number;

	public List<Long> getIndividual() {
		return individual;
	}

	public List<Long> getGenotypeType() {
		return genotypeType;
	}
	public String getSelector() {
		if (selector == null) {
			selector = "ALL";
		}
		if (number == null) {
			number = 1;
		}
		if (getIndividual().size() < number) {
			selector = "ALL";
		}
		return selector.toUpperCase();
	}
	public Integer getNumber() {
		if (number == null) {
			number = 1;
		}
		return number;
	}
}
