package org.uichuimi.database.controllers.variants.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

/**
 * Clase para generar errores personalizados
 */

public class Error {
	private HttpStatus httpStatus;
	private String message;

	public Error(HttpStatus httpStatus, String message) {
		this.httpStatus = httpStatus;
		this.message = message;
	}

	public ResponseEntity GetResponseMessage() {
		Map<String, String> errorResponse = new HashMap<>();
		errorResponse.put("message", this.message);
		errorResponse.put("status", this.httpStatus.BAD_REQUEST.toString());
		ResponseEntity responseEntity = new ResponseEntity(errorResponse, this.httpStatus);
		return responseEntity;
	}

}
