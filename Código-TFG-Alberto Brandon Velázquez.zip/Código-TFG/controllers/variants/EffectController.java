package org.uichuimi.database.controllers.variants;

import io.swagger.annotations.ApiParam;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.uichuimi.database.models.variants.Effect;
import org.uichuimi.database.models.variants.Impact;
import org.uichuimi.database.repositories.variants.EffectRepository;

import java.util.List;

@Controller
public class EffectController {

	private final EffectRepository effectRepository;

	public EffectController(EffectRepository effectRepository) {
		this.effectRepository = effectRepository;
	}

	/** Lista completa de effects **/
	@GetMapping("/effects")
	public ResponseEntity<List<Effect>> getEffects(
		@ApiParam(name = "impacts", value = "List of accepted impacts", allowMultiple = true)
		@RequestParam(name = "impacts", required = false)
			List<Impact> impacts) {
		if(impacts == null){
			return ResponseEntity.ok(effectRepository.findAll());
		}
		return ResponseEntity.ok(effectRepository.findByImpactIn(impacts));
	}

	/** Effects con identificador {id} **/
	@GetMapping("/effects/{id}")
	public ResponseEntity<Effect> getEffect(@PathVariable ("id")Long id){
		return ResponseEntity.ok(effectRepository.findById(id).get());
	}
}

