package org.uichuimi.database.controllers.variants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.LogManager;

@SpringBootApplication(scanBasePackages = {
	"org.uichuimi.database"
})
public class Main {
	static {
		final InputStream resource = Main.class.getResourceAsStream("/lib/logging.properties");
		try {
			LogManager.getLogManager().readConfiguration(resource);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}
}
