package org.uichuimi.database.controllers.variants;

import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.uichuimi.database.models.variants.Population;
import org.uichuimi.database.models.variants.Individual;
import org.uichuimi.database.repositories.variants.PopulationRepository;
import org.uichuimi.database.repositories.variants.IndividualRepository;


import java.util.List;

@Controller
public class PopulationController {

	private final PopulationRepository populationRepository;
	private final IndividualRepository individualRepository;

	public PopulationController(PopulationRepository populationRepository, IndividualRepository individualRepository) {
		this.populationRepository = populationRepository;
		this.individualRepository = individualRepository;

	}


	@GetMapping("/populations")
	public ResponseEntity<List<Population>> getPopulations() {
		return ResponseEntity.ok(populationRepository.findAll());
	}

	@GetMapping("/populations/{id}")
	public ResponseEntity<Population> getPopulation(@PathVariable ("id")Long id){
		return ResponseEntity.ok(populationRepository.findById(id).get());
	}

	@GetMapping("/individuals")
	public ResponseEntity<List<Individual>> getIndividuals(Sort sort) {
		return ResponseEntity.ok(individualRepository.findAll(sort));
	}

	@GetMapping("/individuals/{id}")
	public ResponseEntity<Individual> getIndividual(@PathVariable ("id")Long id) {
		return ResponseEntity.ok(individualRepository.findById(id).get());
	}
}
