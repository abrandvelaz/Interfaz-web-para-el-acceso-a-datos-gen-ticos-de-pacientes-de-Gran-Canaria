package org.uichuimi.database.controllers.variants;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.uichuimi.database.controllers.variants.utils.Error;
import org.uichuimi.database.controllers.variants.utils.PostGenes;
import org.uichuimi.database.models.variants.Biotype;
import org.uichuimi.database.models.variants.Gene;
import org.uichuimi.database.repositories.variants.BiotpyeRepository;
import org.uichuimi.database.repositories.variants.GeneRepository;
import org.uichuimi.database.repositories.variants.TranscriptsRepository;

import java.util.List;

@Controller
public class GeneController{

	private final BiotpyeRepository biotpyeRepository;
	private final GeneRepository geneRepository;
	private final TranscriptsRepository transcriptsRepository;

	public GeneController(GeneRepository geneRepository, BiotpyeRepository biotpyeRepository, TranscriptsRepository transcriptsRepository) {
		this.geneRepository = geneRepository;
		this.biotpyeRepository = biotpyeRepository;
		this.transcriptsRepository = transcriptsRepository;
	}

	/** Páginas de Genes **/
	@GetMapping("/genes")
	public ResponseEntity<Page<Gene>> getgenes(
		@RequestParam(name = "biotypes", required = false) List<Biotype> biotypes, Pageable pageable,
		@RequestParam(name = "search", required = false) String search
	) {
			if(biotypes == null && search == null){
				return ResponseEntity.ok(geneRepository.findAll(pageable));
			}else if (search != null){
				search = "%"+search+"%";
				return ResponseEntity.ok(geneRepository.query(search,pageable));
			}
			return ResponseEntity.ok(geneRepository.findByBiotypeIn(biotypes, pageable));
	}

	/** Genes con identificador {id} **/
	@GetMapping("/genes/{id}")
	public ResponseEntity <Gene> getgene(@PathVariable ("id")Long id){
		return ResponseEntity.ok(geneRepository.findById(id).get());
	}

	/** Lista completa de biotypes **/
	@GetMapping("/biotypes")
	public ResponseEntity<List<Biotype>> getbiotypes() {
		return ResponseEntity.ok(biotpyeRepository.findAll());
	}

	/** Biotypes con identificador {id} **/
	@GetMapping("/biotypes/{id}")
	public ResponseEntity <Biotype> getbiotype(@PathVariable ("id")Long id){
		return ResponseEntity.ok(biotpyeRepository.findById(id).get());
	}

	/** Genes con identificador {id} **/
	@PostMapping("/genes")
	public ResponseEntity <List<Gene>> postGene(@RequestBody PostGenes body){
		if (body.getIds().size() > 200) {
			return new Error(HttpStatus.BAD_REQUEST, "El tamaño no debe superar los 200 elementos").GetResponseMessage();
		}
		return ResponseEntity.ok(geneRepository.findAllById(body.getIds()));
	}
}
