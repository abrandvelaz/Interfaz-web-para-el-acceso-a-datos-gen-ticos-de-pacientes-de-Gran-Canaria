package org.uichuimi.database.controllers.variants;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.uichuimi.database.models.variants.GenotypeType;

import org.uichuimi.database.repositories.variants.Genotype_typeRepository;


import java.util.List;

@Controller
public class Genotype_typeController {

	private final Genotype_typeRepository genotype_typeRepository;

	public Genotype_typeController(Genotype_typeRepository genotype_typeRepository) {
		this.genotype_typeRepository = genotype_typeRepository;
	}

	/** Lista completa de genotypes **/
	@GetMapping("/genotype_type")
	public ResponseEntity<List<GenotypeType>> getGenotype_type() {
		return ResponseEntity.ok(genotype_typeRepository.findAll());
	}



}
