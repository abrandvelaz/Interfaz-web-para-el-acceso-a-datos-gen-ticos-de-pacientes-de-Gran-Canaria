package org.uichuimi.database.controllers.variants;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.uichuimi.database.models.variants.Impact;
import org.uichuimi.database.repositories.variants.ImpactRepository;

import java.util.List;

@Controller
public class ImpactController {

	private final ImpactRepository impactRepository;

	public ImpactController(ImpactRepository impactRepository) {
		this.impactRepository = impactRepository;
	}

	/** Lista completa de impacts **/
	@GetMapping("/impacts")
	public ResponseEntity<List<Impact>> getImpacts() {
		return ResponseEntity.ok(impactRepository.findAll());
	}

	/** Impacts con identificador {id} */
	@GetMapping("/impacts/{id}")
	public ResponseEntity<Impact> getImpact(@PathVariable ("id")Long id){
		return ResponseEntity.ok(impactRepository.findById(id).get());
	}


}
