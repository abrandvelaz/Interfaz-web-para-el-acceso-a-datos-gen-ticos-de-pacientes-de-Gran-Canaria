package org.uichuimi.database.controllers.variants;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.uichuimi.database.controllers.variants.utils.Error;
import org.uichuimi.database.controllers.variants.utils.PostVariants;
import org.uichuimi.database.models.variants.Chromosome;
import org.uichuimi.database.models.variants.VariantProjection;
import org.uichuimi.database.repositories.variants.ChromosomeRepository;
import org.uichuimi.database.repositories.variants.GeneRepository;
import org.uichuimi.database.repositories.variants.PopulationRepository;
import org.uichuimi.database.repositories.variants.VariantRepository;

import java.util.List;

@Controller
public class VariantController {


	private final ChromosomeRepository chromosomeRepository;
	private final GeneRepository geneRepository;
	private final VariantRepository variantRepository;
	private final PopulationRepository populationRepository;

	public VariantController(ChromosomeRepository chromosomeRepository, GeneRepository geneRepository, VariantRepository variantRepository, PopulationRepository populationRepository) {
		this.chromosomeRepository = chromosomeRepository;
		this.geneRepository = geneRepository;
		this.variantRepository = variantRepository;
		this.populationRepository = populationRepository;
	}

	/**
	 * Lista completa de chromosomes
	 **/
	@GetMapping("/chromosomes")
	public ResponseEntity<List<Chromosome>> getChromosomes() {
		return ResponseEntity.ok(chromosomeRepository.findAll());
	}

	/**
	*	Lista completa de variantes
	 **/
	@PostMapping(value = "/variants")
	public ResponseEntity<Page<VariantProjection>> postVariant(
		@RequestBody PostVariants requestBody) {
		// Comprobar si el tamaño de página no sobre pasa el límite
		if (requestBody.getSize() > 200) {
			return new Error(HttpStatus.BAD_REQUEST, "El tamaño de página no debe superar los 200 elementos").GetResponseMessage();
		}
		// Llamada al método independiente de Identfiers
		if (requestBody.getIdentifiers() != null){
			return ResponseEntity.ok(variantRepository.findByIdentifierIn(requestBody.getIdentifiers(), PageRequest.of(requestBody.getPage(), requestBody.getSize())));
		}
		Page<Long> ids = variantRepository.findVariants(
			requestBody.getGenes(),
			requestBody.getStart(),
			requestBody.getEnd(),
			requestBody.getChromosomes(),
			requestBody.getBiotypes(),
			requestBody.getGmaf(),
			requestBody.getPolyphen(),
			requestBody.getSift(),
			requestBody.getEffects(),
			requestBody.getImpacts(),
			requestBody.getGenotypeFilters(),
			PageRequest.of(requestBody.getPage(), requestBody.getSize()));
		Page<VariantProjection> page = new PageImpl<>(variantRepository.findByIdIn(ids.getContent()), ids.getPageable(), ids.getTotalElements());
		return ResponseEntity.ok(page);
	}
}
