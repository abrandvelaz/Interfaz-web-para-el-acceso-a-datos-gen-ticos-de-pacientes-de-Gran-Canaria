package org.uichuimi.database.models.variants;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.springframework.data.rest.core.config.Projection;

import javax.persistence.*;
import java.util.*;

@Table(name = "variants")
@Entity(name = "variant")
public class Variant implements Comparable<Variant> {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@JoinColumn(nullable = false)
	@Fetch(FetchMode.SELECT)
	@ManyToOne(optional = false)
	private Chromosome chromosome;

	private Long position;

	private String reference;

	private String alternative;

	private String identifier;

	@OneToMany(mappedBy = "variant", orphanRemoval = true, fetch = FetchType.LAZY)
	@JsonManagedReference
	private Set<Consequence> consequences = new HashSet<>();


	@OneToMany(mappedBy = "variant", orphanRemoval = true, fetch = FetchType.LAZY)
	@Fetch(FetchMode.SELECT)
	@JsonManagedReference
	private Set<Genotype> genotypes;


	@OneToMany(fetch = FetchType.EAGER, mappedBy = "variant", orphanRemoval = true)
	@Fetch(FetchMode.JOIN)
	@JsonManagedReference
	private Set<Frequency> frequencies = new HashSet<>();

	public Variant() {
	}

	public Variant(Long id, Chromosome chromosome, Long position, String reference, String alternative, String identifier, Set<Consequence> consequences, Set<Genotype> genotypes, Set<Frequency> frequencies) {
		this.id = id;
		this.chromosome = chromosome;
		this.position = position;
		this.reference = reference;
		this.alternative = alternative;
		this.identifier = identifier;
		this.consequences = consequences;
		this.genotypes = genotypes;
		this.frequencies = frequencies;
	}

	public List<Genotype> getGenotypes() { return new ArrayList<> (genotypes); }

	public Long getId() {return id;}

	public Chromosome getChromosome() {return chromosome;}

	public String getIdentifier() {
		return identifier;
	}

	public String getAlternative() {
		return alternative;
	}

	public String getReference() {
		return reference;
	}

	public Long getPosition() {
		return position;
	}

	public List<Frequency> getFrequencies() { return new ArrayList<> (frequencies); }

	public List<Consequence> getConsequences() { return new ArrayList<>(consequences); }

	@Override
	public int compareTo(Variant o) {
		return Comparator.comparing(Variant::getChromosome)
				.thenComparingLong(Variant::getPosition)
				.thenComparing(Variant::getReference)
				.thenComparing(Variant::getAlternative)
				.compare(this, o);
	}



	@Override
	public String toString() {
		return "Variant{" +
				"id=" + id +
				", chromosome=" + chromosome +
				", position=" + position +
				", reference='" + reference + '\'' +
				", alternative='" + alternative + '\'' +
				", identifier='" + identifier + '\'' +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Variant variant = (Variant) o;
		return Objects.equals(id, variant.id) && Objects.equals(chromosome, variant.chromosome) && Objects.equals(position, variant.position) && Objects.equals(reference, variant.reference) && Objects.equals(alternative, variant.alternative) && Objects.equals(identifier, variant.identifier) && Objects.equals(consequences, variant.consequences) && Objects.equals(genotypes, variant.genotypes) && Objects.equals(frequencies, variant.frequencies);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}


}
