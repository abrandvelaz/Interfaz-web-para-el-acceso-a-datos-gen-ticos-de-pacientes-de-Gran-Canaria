package org.uichuimi.database.models.variants;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "individuals")
@Entity(name = "individual")
public class Individual {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(unique = true, length = 20)
	private String code;

	public Individual() {
	}

	public Individual(Long id, String code) {
		this.id = id;
		this.code = code;
	}

	public Long getId() {
		return id;
	}

	public String getCode() {
		return code;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Individual that = (Individual) o;
		return Objects.equals(id, that.id) && Objects.equals(code, that.code);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, code);
	}

	@Override
	public String toString() {
		return "Individual{" +
				"id=" + id +
				", code='" + code + '\'' +
				'}';
	}
}
