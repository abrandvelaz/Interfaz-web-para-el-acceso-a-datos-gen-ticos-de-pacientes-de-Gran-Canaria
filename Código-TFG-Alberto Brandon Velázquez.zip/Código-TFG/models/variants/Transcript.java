package org.uichuimi.database.models.variants;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "transcripts")
@Entity(name = "transcript")
public class Transcript {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@ManyToOne
	private Gene gene;

	@Column(unique = true)
	private String enst;

	private String type;

	public Transcript() {
	}

	public Transcript(Long id, Gene gene, String enst, String type) {
		this.id = id;
		this.gene = gene;
		this.enst = enst;
		this.type = type;
	}

	public Long getId() {
		return id;
	}

	public Gene getGene() {
		return gene;
	}

	public String getEnst() {
		return enst;
	}

	public String getType() {
		return type;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Transcript that = (Transcript) o;
		return Objects.equals(id, that.id) && Objects.equals(gene, that.gene) && Objects.equals(enst, that.enst) && Objects.equals(type, that.type);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, gene, enst, type);
	}

	@Override
	public String toString() {
		return "Transcript{" +
				"id=" + id +
				", gene=" + gene +
				", enst='" + enst + '\'' +
				", type='" + type + '\'' +
				'}';
	}
}
