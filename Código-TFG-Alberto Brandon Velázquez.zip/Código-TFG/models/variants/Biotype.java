package org.uichuimi.database.models.variants;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Hibernate;
import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "biotypes", indexes = {
		@Index(name = "name_index", columnList = "name", unique = true)
})
@Entity(name = "biotype")
public class Biotype {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@NaturalId
	@Column(nullable = false, unique = true)
	private String accession;
	@Column(nullable = false, unique = true)
	private String name;
	@Column(nullable = false, length = -1)
	private String description;

	public Biotype() {
	}

	public Biotype(Long id, String accession, String name, String description) {
		this.id = id;
		this.accession = accession;
		this.name = name;
		this.description = description;
	}

	public Long getId() {
		return id;
	}

	public String getAccession() {
		return accession;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	@Override
	public String toString() {
		return "Biotype{" +
				"id=" + id +
				", accession='" + accession + '\'' +
				", name='" + name + '\'' +
				", description='" + StringUtils.abbreviate(description, 20) + '\'' +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o))
			return false;
		Biotype biotype = (Biotype) o;
		return id != null && Objects.equals(id, biotype.id)
				&& accession != null && Objects.equals(accession, biotype.accession);
	}

	@Override
	public int hashCode() {
		return Objects.hash(accession);
	}
}
