package org.uichuimi.database.models.variants;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "frequencies")
@Entity(name = "frequency")
public class Frequency {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@ManyToOne
	private Population population;

	@ManyToOne
	@JsonBackReference
	private Variant variant;

	@Column(name = "ac")
	private int ac;

	@Column(name = "an")
	private int an;

	@Column(name = "af")
	private double af;

	public Frequency() {
	}

	public Frequency(Long id, Population population, Variant variant, int ac, int an, double af) {
		this.id = id;
		this.population = population;
		this.variant = variant;
		this.ac = ac;
		this.an = an;
		this.af = af;
	}

	public Long getId() {
		return id;
	}

	public Population getPopulation() {
		return population;
	}

	public int getAc() {
		return ac;
	}

	public int getAn() {
		return an;
	}

	public double getAf() {
		return af;
	}

	public Variant getVariant() {
		return variant;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Frequency frequency = (Frequency) o;
		return ac == frequency.ac && an == frequency.an && Double.compare(frequency.af, af) == 0 && Objects.equals(id, frequency.id) && Objects.equals(population, frequency.population) && Objects.equals(variant, frequency.variant);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
}
