package org.uichuimi.database.models.variants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import java.util.List;

@Projection(types = Variant.class, name = "customVariant")
public interface VariantProjection {

	@Value("#{target.id}")
	Long getId();

	@Value("#{target.chromosome.id}")
	Long getChromosome();

	Long getPosition();

	String getReference();

	String getAlternative();

	String getIdentifier();

	@Value("#{target.consequences}")
	List<ConsequenceProjection> getConsequence();

	@Value("#{target.frequencies}")
	List<FrequencyProjection> getFrequencies();

	@Value("#{target.genotypes}")
	List<GenotypeProjection> getGenotypes();

}
