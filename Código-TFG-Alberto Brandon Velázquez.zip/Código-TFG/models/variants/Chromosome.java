package org.uichuimi.database.models.variants;

import org.jetbrains.annotations.NotNull;

import javax.persistence.*;
import java.util.Comparator;
import java.util.Objects;

@Entity(name = "chromosome")
@Table(
		name = "chromosomes",
		indexes = {
				@Index(name = "uk_chromosomes_genebank", columnList = "genebank"),
				@Index(name = "uk_chromosomes_ncbi", columnList = "ncbi"),
				@Index(name = "uk_chromosomes_refseq", columnList = "refseq"),
				@Index(name = "uk_chromosomes_ucsc", columnList = "ucsc"),
				@Index(name = "uk_chromosomes_sequence", columnList = "sequence")
		}
)
public class Chromosome implements Comparable<Chromosome> {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(nullable = false, unique = true, updatable = false)
	private String ncbi;
	@Column(nullable = false, unique = true, updatable = false)
	private String genebank;
	@Column(nullable = false, unique = true)
	private String refseq;
	@Column(nullable = false, unique = true)
	private String ucsc;
	@Column(nullable = false, unique = true)
	private Integer sequence;
	@Column(nullable = false, unique = true)
	private Long length;

	public Chromosome() {
	}

	public Chromosome(Long id, String ncbi, String genebank, String refseq, String ucsc, Integer sequence, Long length) {
		this.id = id;
		this.ncbi = ncbi;
		this.genebank = genebank;
		this.refseq = refseq;
		this.ucsc = ucsc;
		this.sequence = sequence;
		this.length = length;
	}

	public Long getId() {
		return id;
	}

	public String getNcbi() {
		return ncbi;
	}

	public String getGenebank() {
		return genebank;
	}

	public String getRefseq() {
		return refseq;
	}

	public String getUcsc() {
		return ucsc;
	}

	public Integer getSequence() {
		return sequence;
	}

	public Long getLength() {
		return length;
	}

	@Override
	public String toString() {
		return "Chromosome{" +
				"id=" + id +
				", ncbi='" + ncbi + '\'' +
				", genebank='" + genebank + '\'' +
				", refseq='" + refseq + '\'' +
				", ucsc='" + ucsc + '\'' +
				", sequence=" + sequence +
				", length=" + length +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Chromosome that = (Chromosome) o;
		return Objects.equals(id, that.id)
				&& Objects.equals(ncbi, that.ncbi)
				&& Objects.equals(genebank, that.genebank)
				&& Objects.equals(refseq, that.refseq)
				&& Objects.equals(ucsc, that.ucsc)
				&& Objects.equals(sequence, that.sequence)
				&& Objects.equals(length, that.length);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, ncbi, genebank, refseq, ucsc, sequence, length);
	}

	@Override
	public int compareTo(@NotNull Chromosome o) {
		return Comparator.comparing(Chromosome::getSequence).compare(this, o);
	}
}
