package org.uichuimi.database.models.variants;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "genotypes")
@Entity(name = "genotype")
public class Genotype {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;
	@JoinColumn(nullable = false)
	@ManyToOne(optional = false)
	@JsonBackReference
	private Variant variant;
	@ManyToOne
	private Individual individual;
	@Column(name = "reference_count")
	private int refCount;
	@Column(name = "alternative_count")
	private int altCount;
	@ManyToOne
	@JoinColumn(name = "genotype_type_id", referencedColumnName = "id")
	private GenotypeType genotypeTypeId;

	public Genotype() {
	}

	public Genotype(Long id, Variant variant, Individual individual, int refCount, int altCount, GenotypeType genotypeTypeId) {
		this.id = id;
		this.variant = variant;
		this.individual = individual;
		this.refCount = refCount;
		this.altCount = altCount;
		this.genotypeTypeId = genotypeTypeId;
	}

	public GenotypeType getGenotypeTypeId() {return genotypeTypeId;}

	public Long getId() {
		return id;
	}

	public Variant getVariant() {
		return variant;
	}

	public Individual getIndividual() {
		return individual;
	}

	public int getRefCount() {
		return refCount;
	}

	public int getAltCount() {
		return altCount;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Genotype genotype = (Genotype) o;
		return refCount == genotype.refCount && altCount == genotype.altCount && Objects.equals(id, genotype.id) && Objects.equals(variant, genotype.variant) && Objects.equals(individual, genotype.individual) && Objects.equals(genotypeTypeId, genotype.genotypeTypeId);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public String toString() {
		return "Genotype{" +
				"id=" + id +
				", variant=" + variant +
				", individual=" + individual +
				", refCount=" + refCount +
				", altCount=" + altCount +
				", genotypeTypeId=" + genotypeTypeId +
				'}';
	}
}
