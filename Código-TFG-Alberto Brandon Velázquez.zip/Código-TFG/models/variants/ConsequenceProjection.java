package org.uichuimi.database.models.variants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import javax.persistence.Id;

@Projection(types = Consequence.class)
public interface ConsequenceProjection {

	@Value("#{target.transcript.id}")
	Long getTranscript();

	@Value("#{target.transcript.gene.id}")
	Long getGene();

	@Value("#{target.effect.id}")
	Long getEffect();

	@Value("#{target.effect.impact.id}")
	Long getImpact();

	Double getSift();

	Double getPolyphen();

	String getHgvsc();

	String getHgvsp();


}
