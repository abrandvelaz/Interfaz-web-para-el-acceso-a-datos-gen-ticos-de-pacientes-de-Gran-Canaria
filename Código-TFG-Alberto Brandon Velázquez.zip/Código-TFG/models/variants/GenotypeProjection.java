package org.uichuimi.database.models.variants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import javax.persistence.Id;

@Projection(types = Genotype.class)
public interface GenotypeProjection {


	@Value("#{target.individual.id}")
	Long getIndividual();

	int getRefCount();

	int getAltCount();

	@Value("#{target.genotypeTypeId.id}")
	Long getGenotypeType();
}
