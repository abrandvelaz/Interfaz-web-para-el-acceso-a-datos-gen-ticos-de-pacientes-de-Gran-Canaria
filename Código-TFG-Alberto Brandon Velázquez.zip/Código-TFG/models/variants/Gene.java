package org.uichuimi.database.models.variants;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Table(name = "genes")
@Entity(name = "gene")
public class Gene {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@NaturalId
	@Column(nullable = false, unique = true)
	private String ensg;

	@Column(unique = true)
	private String hgnc;
	@Column(unique = true)
	private String ncbi;

	@Column(nullable = false)
	private String symbol;
	private String name;

	@JoinColumn
	@ManyToOne(cascade = {CascadeType.ALL})
	private Biotype biotype;

	@JsonIgnore
	@OneToMany(mappedBy = "gene", orphanRemoval = true, fetch = FetchType.LAZY)
	private List<Transcript> transcripts;

	public Gene() {
	}

	public Gene(Long id, String ensg, String hgnc, String ncbi, String symbol, String name, Biotype biotype, List<Transcript> transcripts) {
		this.id = id;
		this.ensg = ensg;
		this.hgnc = hgnc;
		this.ncbi = ncbi;
		this.symbol = symbol;
		this.name = name;
		this.biotype = biotype;
		this.transcripts = transcripts;
	}

	public Long getId() {
		return id;
	}

	public List<Transcript> getTranscripts() {return transcripts;}

	public String getName() {
		return name;
	}

	public String getHgnc() {
		return hgnc;
	}

	public String getNcbi() {
		return ncbi;
	}

	public String getEnsg() {
		return ensg;
	}

	public String getSymbol() {
		return symbol;
	}

	public Biotype getBiotype() {
		return biotype;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		if (!super.equals(o)) return false;
		Gene gene = (Gene) o;
		return hgnc.equals(gene.hgnc);
	}

	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), hgnc);
	}

	@Override
	public String toString() {
		return "Gene{" +
			"id=" + id +
			", hgnc='" + hgnc + '\'' +
			", ncbi='" + ncbi + '\'' +
			", ensg='" + ensg + '\'' +
			", symbol='" + symbol + '\'' +
			", name='" + name + '\'' +
			", biotype=" + biotype +
			", transcripts=" + transcripts +
			'}';
	}
}
