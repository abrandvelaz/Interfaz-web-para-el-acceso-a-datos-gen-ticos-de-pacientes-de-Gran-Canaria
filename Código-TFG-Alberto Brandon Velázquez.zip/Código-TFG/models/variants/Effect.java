package org.uichuimi.database.models.variants;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "effects")
@Entity(name = "effect")
public class Effect {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(nullable = false)
	private String name;
	@Column(length = 25, nullable = false)
	private String accession;
	@Column(length = -1, nullable = false)
	private String description;
	@ManyToOne
	@JoinColumn(name = "impact_id")
	private Impact impact;

	public Effect() {
	}

	public Effect(Long id, String name, String accession, String description, Impact impact) {
		this.id = id;
		this.name = name;
		this.accession = accession;
		this.description = description;
		this.impact = impact;
	}

	public String getAccession() {
		return accession;
	}

	public String getDescription() {
		return description;
	}

	public String getName() {
		return name;
	}

	public Impact getImpact() {
		return impact;
	}

	public Long getId() {
		return id;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Effect effect = (Effect) o;
		return Objects.equals(id, effect.id) && Objects.equals(name, effect.name) && Objects.equals(accession, effect.accession) && Objects.equals(description, effect.description) && Objects.equals(impact, effect.impact);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, accession, description, impact);
	}

	@Override
	public String toString() {
		return "Effect{" +
				"id=" + id +
				", name='" + name + '\'' +
				", accession='" + accession + '\'' +
				", description='" + description + '\'' +
				", impact=" + impact +
				'}';
	}
}
