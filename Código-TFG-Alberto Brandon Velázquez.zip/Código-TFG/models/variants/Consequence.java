package org.uichuimi.database.models.variants;

import com.fasterxml.jackson.annotation.JsonBackReference;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.Objects;

@Table(name = "consequences")
@Entity(name = "consequence")
public class Consequence {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@ManyToOne
	@JoinColumn
	@JsonBackReference
	private Variant variant;

	@ManyToOne
	private Transcript transcript;

	@ManyToOne
	private Effect effect;

	private Double sift;
	private Double polyphen;

	private String hgvsc;
	private String hgvsp;

	public Consequence() {
	}

	public Consequence(Long id, Variant variant, Transcript transcript, Effect effect, Double sift, Double polyphen, String hgvsc, String hgvsp) {
		this.id = id;
		this.variant = variant;
		this.transcript = transcript;
		this.effect = effect;
		this.sift = sift;
		this.polyphen = polyphen;
		this.hgvsc = hgvsc;
		this.hgvsp = hgvsp;
	}

	public Long getId() {
		return id;
	}

	public Variant getVariant() {
		return variant;
	}

	public Transcript getTranscript() {
		return transcript;
	}

	public Effect getEffect() {
		return effect;
	}

	public Double getSift() {
		return sift;
	}

	public Double getPolyphen() {
		return polyphen;
	}

	public String getHgvsc() {
		return hgvsc;
	}

	public String getHgvsp() {
		return hgvsp;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o))
			return false;
		Consequence that = (Consequence) o;
		return id != null && Objects.equals(id, that.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}
}
