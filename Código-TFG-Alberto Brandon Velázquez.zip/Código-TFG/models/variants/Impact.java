package org.uichuimi.database.models.variants;

import javax.persistence.*;
import java.util.Objects;

@Entity(name = "impact")
@Table(name = "impacts")
public class Impact {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(nullable = false, unique = true)
	private String name;

	@Column(nullable = false, unique = true)
	private Integer sequence;

	public Impact() {
	}

	public Impact(Long id, String name, Integer sequence) {
		this.id = id;
		this.name = name;
		this.sequence = sequence;
	}

	public Long getId() {
		return id;
	}

	public Integer getSequence() {return sequence;}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public String getName() {return name;}

	@Override
	public String toString() {
		return "Impact{" +
				"id=" + id +
				", name='" + name + '\'' +
				", sequence=" + sequence +
				'}';
	}
}
