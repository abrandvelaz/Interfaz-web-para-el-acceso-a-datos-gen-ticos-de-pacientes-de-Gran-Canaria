package org.uichuimi.database.models.variants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.core.config.Projection;

import javax.persistence.Id;


@Projection(types = Frequency.class)
public interface FrequencyProjection {



	@Value("#{target.population.id}")
	Long getPopulation();

	int getAc();

	int getAn();

	double getAf();

}
