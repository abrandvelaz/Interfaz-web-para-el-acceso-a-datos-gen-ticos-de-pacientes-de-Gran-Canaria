package org.uichuimi.database.models.users;

import javax.persistence.*;
import java.io.Serializable;

@Entity(name = "User")
@Table(name = "login")
public class User implements Serializable {

	private static final long serialVersionUID = -2343243243242432341L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long user_id;

	@Column(unique = true)
	private String username;

	private String password;

	protected User() {	}

	public User(String username, String password) {
		this.username = username;
		this.password = password;
	}

	public long getId() {
		return user_id;
	}

	public void setId(long id) {
		this.user_id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
