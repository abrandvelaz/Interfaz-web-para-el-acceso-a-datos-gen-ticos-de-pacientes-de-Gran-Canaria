package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.uichuimi.database.models.variants.Biotype;

import java.util.Collection;
import java.util.List;

public interface BiotpyeRepository extends JpaRepository<Biotype, Long> {

	List<Biotype> findAll();

	@Query("select distinct b " +
		"from biotype b " +
		"where b.accession in ?1 " +
		"or b.name in ?1")
	List<Biotype> query(Collection<String> biotype);

}
