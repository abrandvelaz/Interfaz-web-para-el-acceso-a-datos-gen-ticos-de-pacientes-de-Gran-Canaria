package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.uichuimi.database.models.variants.Consequence;

public interface ConsequenceRepository extends JpaRepository<Consequence, Long> {


}
