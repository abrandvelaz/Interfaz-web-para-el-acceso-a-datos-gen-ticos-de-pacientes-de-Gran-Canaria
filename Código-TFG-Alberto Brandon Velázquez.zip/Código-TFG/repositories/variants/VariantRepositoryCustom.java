package org.uichuimi.database.repositories.variants;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.uichuimi.database.controllers.variants.utils.GenotypeFilter;

import java.util.List;

public interface VariantRepositoryCustom {
	Page<Long> findVariants(List<Long> genes, Long start, Long end, List<Long> chromosomes, List<Long> biotypes, Double gmaf, Double polyphen, Double sift, List<Long> effects, List<Long> impacts, List<GenotypeFilter> genotypeFilters, Pageable pageable);
}
