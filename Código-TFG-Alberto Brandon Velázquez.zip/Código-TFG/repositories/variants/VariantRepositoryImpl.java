package org.uichuimi.database.repositories.variants;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.uichuimi.database.controllers.variants.utils.GenotypeFilter;
import org.uichuimi.database.models.variants.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

public class VariantRepositoryImpl implements VariantRepositoryCustom {

	private final PopulationRepository populationRepository;

	public VariantRepositoryImpl(PopulationRepository populationRepository) {
		this.populationRepository = populationRepository;
	}

	@PersistenceContext
	private EntityManager entityManager;
	private List<Consequence> resultListConsequences;

	@Override
	public Page<Long> findVariants(List<Long> genes, Long start, Long end, List<Long> chromosomes, List<Long> biotypes, Double gmaf, Double polyphen, Double sift, List<Long> effects, List<Long> impacts, List<GenotypeFilter> genotypeFilters, Pageable pageable) {

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Tuple> query = cb.createTupleQuery();
		Root<Variant> variant = query.from(Variant.class);

		//Generación de los JOIN más usados
		Join<Variant, Consequence> consequences = null;
		Join<Consequence, Transcript> transcripts = null;

		//Cosas que van en el WHERE
		List<Predicate> predicates = new ArrayList<>();
		if (start != null) {
			predicates.add(cb.ge(variant.get("position"), start));
		}
		if (end != null) {
			predicates.add(cb.le(variant.get("position"), end));
		}
		if (chromosomes != null) {
			//predicates.add(variant.get("chromosome").in(chromosomes.stream().map(cb::literal).toArray()));
			predicates.add(variant.get("chromosome").in(chromosomes));
		}
		if (genes != null) {
			consequences = variant.join("consequences", JoinType.INNER);
			transcripts = consequences.join("transcript", JoinType.INNER);
			//predicates.add(transcripts.get("gene").in(genes.stream().map(cb::literal).toArray()));
			predicates.add(transcripts.get("gene").in(genes));
		}
		if (biotypes != null) {
			if (consequences == null) {
				consequences = variant.join("consequences", JoinType.INNER);
			}
			if (transcripts == null){
				transcripts = consequences.join("transcript", JoinType.INNER);
			}
			Join<Consequence, Gene> geness = transcripts.join("gene", JoinType.INNER);
			//predicates.add(geness.get("biotype").in(biotypes.stream().map(cb::literal).toArray()));
			predicates.add(geness.get("biotype").in(biotypes));
		}
		if (gmaf != null) {
			Population populations = populationRepository.findByCode("all");
			Join<Variant, Frequency> frequencies = variant.join("frequencies", JoinType.INNER);
			predicates.add(cb.equal(frequencies.get("population"), populations.getId()));
			predicates.add(cb.le(frequencies.get("af"), gmaf));
		}
		if (polyphen != null) {
			if (consequences == null) {
				consequences = variant.join("consequences", JoinType.INNER);
			}
			predicates.add(cb.ge(consequences.get("polyphen"), polyphen));
		}
		if (sift != null) {
			if (consequences == null) {
				consequences = variant.join("consequences", JoinType.INNER);
			}
			predicates.add(cb.le(consequences.get("sift"), sift));
		}
		if (effects != null){
			if (consequences == null) {
				consequences = variant.join("consequences", JoinType.INNER);
			}
			//predicates.add(consequences.get("effect").in(effects.stream().map(cb::literal).toArray()));
			predicates.add(consequences.get("effect").in(effects));
		}
		if (impacts != null){
			if (consequences == null) {
				consequences = variant.join("consequences", JoinType.INNER);
			}
			Join<Variant, Effect> effectes = consequences.join("effect", JoinType.INNER);
			//predicates.add(effectes.get("impact").in(impacts.stream().map(cb::literal).toArray()));
			predicates.add(effectes.get("impact").in(impacts));
		}
		if (genotypeFilters != null){
			Join<Variant, Genotype> genotypes = variant.join("genotypes", JoinType.INNER);
			for(GenotypeFilter genotypeFilter : genotypeFilters)
			{
				CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
				// ALL y NONE
				if (genotypeFilter.getSelector().equals("ALL") || genotypeFilter.getSelector().equals("NONE"))
				{
					for (Long indiv : genotypeFilter.getIndividual())
					{
						Subquery<Integer> subQuery = query.subquery(Integer.class);
						Root<Genotype> pc = subQuery.from(Genotype.class);
						List<Predicate> predicatessub = new ArrayList<>();
						// Generando los predicados
						predicatessub.add(criteriaBuilder.equal(pc.get("variant"), variant.get("id")));
						predicatessub.add(criteriaBuilder.equal(pc.get("individual"), indiv));
						predicatessub.add(pc.get("genotypeTypeId").in(genotypeFilter.getGenotypeType()));
						// Construir la subquery
						subQuery.select(pc.get("id")).where(predicatessub.toArray(new Predicate[0]));
						// Añadir al predicado
						if (genotypeFilter.getSelector().equals("ALL")) {
							// Construir la subquery
							predicates.add(cb.exists(subQuery));
						} else {
							// Construir la subquery
							predicates.add(cb.exists(subQuery).not());
						}
					}
				} else {
					//ANY
					if (genotypeFilter.getSelector().equals("ANY")) {
						// Obtener la lista por medio de ejecutar el group by
						CriteriaBuilder cbany = entityManager.getCriteriaBuilder();
						CriteriaQuery<Tuple> qany = cb.createTupleQuery();
						Root<Genotype> anygeno = qany.from(Genotype.class);
						List<Predicate> pdany = new ArrayList<>();
						pdany.add(anygeno.get("individual").in(genotypeFilter.getIndividual()));
						pdany.add(anygeno.get("genotypeTypeId").in(genotypeFilter.getGenotypeType()));
						qany = qany.where(pdany.toArray(new Predicate[0]));
						CriteriaQuery<Tuple> anygrp = qany.multiselect(anygeno.get("variant").get("id"),
							cb.max(anygeno.get("individual").get("id")),
							cb.count(anygeno)).groupBy(anygeno.get("variant").get("id")).having(cbany.ge(cb.count(anygeno),
							genotypeFilter.getNumber()));
						List<Tuple> anytuple = entityManager.createQuery(anygrp).getResultList();
						List<Long> anyresultlist = new ArrayList<>();
						anytuple.forEach(t -> anyresultlist.add((Long) t.get(0)));
						// Agregar la lista de id de variant al predicado
						predicates.add(variant.get("id").in(anyresultlist));
					}
				}
			}
		}
		// Asigna el where de la query
		query = query.where(predicates.toArray(new Predicate[0]));
		// Prepara la query para contar el total de registros
		CriteriaQuery<Tuple> countQuery = query.multiselect(cb.countDistinct(variant));
		Tuple numregtuple = entityManager.createQuery(countQuery).getSingleResult();
		Long numreg = (Long) numregtuple.get(0);
		// Prepara query para extraer los datos
		query = query.multiselect(variant.get("id"), variant.get("chromosome").get("sequence"), variant.get("position")).distinct(true);
		query.orderBy(cb.asc(variant.get("chromosome").get("sequence")), cb.asc(variant.get("position")));
		TypedQuery<Tuple> managerQuery = entityManager.createQuery(query);
		List<Tuple> resultListTuples = managerQuery.setFirstResult(pageable.getPageNumber() * pageable.getPageSize()).setMaxResults(pageable.getPageSize()).getResultList();
		// Convertir la lista de tuplas en una lista de variant.id
		List<Long> resultlist = new ArrayList<>();
		resultListTuples.forEach(t -> resultlist.add((Long) t.get(0)));
		return new PageImpl<Long>(resultlist, pageable, numreg);
	}

}
