package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.uichuimi.database.models.variants.GenotypeType;

public interface Genotype_typeRepository extends JpaRepository<GenotypeType, Long> {
}
