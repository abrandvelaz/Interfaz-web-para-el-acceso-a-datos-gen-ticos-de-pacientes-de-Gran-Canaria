package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.uichuimi.database.models.variants.Effect;
import org.uichuimi.database.models.variants.Impact;

import java.util.List;

public interface EffectRepository extends JpaRepository<Effect, Long> {
	List<Effect> findByImpactIn(List<Impact> impacts);
}
