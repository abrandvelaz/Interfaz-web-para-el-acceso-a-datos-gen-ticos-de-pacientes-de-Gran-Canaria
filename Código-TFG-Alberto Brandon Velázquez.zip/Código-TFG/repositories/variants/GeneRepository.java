package org.uichuimi.database.repositories.variants;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.uichuimi.database.models.variants.Biotype;
import org.uichuimi.database.models.variants.Gene;

import java.util.List;


public interface GeneRepository extends JpaRepository<Gene, Long> {
	Page<Gene> findByBiotypeIn(List<Biotype> biotypes, Pageable pageable);

	@Query("select g " +
		"from gene g " +
		"where g.hgnc like upper(?1)  " +
		"or g.ensg like upper(?1) " +
		"or g.ncbi like upper(?1) " +
		"or g.symbol like upper(?1)")
	Page<Gene> query(String search, Pageable pageable);

	@Query(
		value = "select id from gene"
	)
	List<Long> findById();

}
