package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.uichuimi.database.models.variants.Gene;
import org.uichuimi.database.models.variants.Transcript;



import java.util.List;

public interface TranscriptsRepository extends JpaRepository<Transcript, Long> {
	List <Transcript> findByGeneIn(List<Gene> genes);
}
