package org.uichuimi.database.repositories.variants;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.uichuimi.database.models.variants.Variant;
import org.uichuimi.database.models.variants.VariantProjection;

import java.util.List;

public interface VariantRepository extends JpaRepository<Variant, Long>, VariantRepositoryCustom {
	Page<VariantProjection> findByIdentifierIn(List<String> identifiers, Pageable pageable);
	@EntityGraph(attributePaths = {"chromosome", "frequencies", "consequences", "genotypes", "consequences.transcript", "consequences.effect"})
	List<VariantProjection> findByIdIn(List<Long> ids);
}
