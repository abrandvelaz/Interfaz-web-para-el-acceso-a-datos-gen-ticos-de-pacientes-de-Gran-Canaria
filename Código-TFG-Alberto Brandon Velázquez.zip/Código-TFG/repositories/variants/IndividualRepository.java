package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.uichuimi.database.models.variants.Individual;

public interface IndividualRepository extends JpaRepository<Individual, Long> {

}
