package org.uichuimi.database.repositories.variants;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.uichuimi.database.models.variants.Chromosome;

import java.util.Collection;
import java.util.List;

public interface ChromosomeRepository extends JpaRepository<Chromosome, Long> {

	@Query("select distinct c " +
		"from chromosome c " +
		"where c.ncbi in ?1 " +
		"or c.refseq in ?1 " +
		"or c.ucsc in ?1 " +
		"or c.genebank in ?1 " +
		"order by c.sequence")
	List<Chromosome> query(Collection<String> chrom);
	@Query(
		value = "select id from chromosome"
	)
	List<Long> findById();
}
